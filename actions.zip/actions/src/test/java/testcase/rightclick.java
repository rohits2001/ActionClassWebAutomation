package testcase;

import base.basetest;
import pages.checkboxpage;
import pages.handlealertspage;
import pages.keyboardseventpage;
import pages.multiplewindowspage;
import pages.rightclickpage;
import pages.sliderpage;
import pages.checkboxpage;
import utilities.readXLData;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class rightclick extends basetest {
	
	rightclickpage rightclick;
	
	
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void rightclick(String Email, String password) throws InterruptedException, IOException {

	
	rightclick = new rightclickpage(driver);
	rightclick.clickonbutton_start();
}
}