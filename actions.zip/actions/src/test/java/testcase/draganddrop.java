package testcase;

import base.basetest;
import pages.draganddroppage;
import utilities.readXLData;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class draganddrop extends basetest {
	
	draganddroppage draganddrop;
	
	
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void login(String Email, String password) throws InterruptedException, IOException {

	
	draganddrop = new draganddroppage(driver);
	draganddrop.draganddrop();
}
}