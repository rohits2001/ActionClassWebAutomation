package testcase;

import base.basetest;
import pages.dropdownpage;
import utilities.readXLData;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class dropdown extends basetest {

    dropdownpage dropdown;

    @Test(dataProviderClass = readXLData.class, dataProvider = "testData")
    public void dropdown(String Email, String password) throws InterruptedException, IOException {
        // Test dropdown functionality
    	
    	dropdown = new dropdownpage(driver); 
        dropdown.dropdowntest();
        dropdown.dropdownoptiontest();
    }
}
