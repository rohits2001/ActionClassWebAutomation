package testcase;

import base.basetest;
import pages.checkboxpage;
import pages.handlealertspage;
import pages.keyboardseventpage;
import pages.multiplewindowspage;
import pages.checkboxpage;
import utilities.readXLData;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class multiplewindows extends basetest {
	
	multiplewindowspage multiplewindows;
	
	
	@Test(dataProviderClass = readXLData.class, dataProvider = "testData")
	public void login(String Email, String password) throws InterruptedException, IOException {

	
	multiplewindows = new multiplewindowspage(driver);
	multiplewindows.clickonmultiplewindows();
}
}