package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import base.basetest;

import java.time.Duration;
import java.util.Set;

public class keyboardseventpage extends basetest{
    WebDriver driver;
    
    WebElement click_keyboardsevent;

    public keyboardseventpage(WebDriver driver) {
        this.driver = driver;
    }
    public void clickonkeyboardsevent() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("click_keyboardsevent")))).click();
        new Actions(driver)
        .keyDown(Keys.PAGE_DOWN)
        .perform();
    }
}