package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import base.basetest;

import java.time.Duration;
import java.util.Set;

public class multiplewindowspage extends basetest{
    WebDriver driver;
    
    WebElement click_multiplewindows;

    public multiplewindowspage(WebDriver driver) {
        this.driver = driver;
    }
    public void clickonmultiplewindows() {
    	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("click_multiplewindows")))).click();
        Object[] windowhandles=driver.getWindowHandles().toArray();
        driver.switchTo().window((String) windowhandles[1]);
        //assert on title of new window
        String title=driver.getTitle();
    }
}