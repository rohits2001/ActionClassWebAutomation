package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
 
import base.basetest;
 
public class rightclickpage extends basetest {
	WebElement btn_start;
	public rightclickpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
 
}
 
	public void clickonbutton_start() {
		WebElement rightclick=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("btn_start"))));
		Actions actions = new Actions(driver);
		actions.contextClick(rightclick).perform();
}
}