package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import base.basetest;

import java.time.Duration;
import java.util.Set;

public class checkboxpage extends basetest{
    WebDriver driver;
    
    WebElement click_checkbox;

    public checkboxpage(WebDriver driver) {
        this.driver = driver;
    }
    public void clickoncheckbox() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("click_checkbox")))).click();
	}
}