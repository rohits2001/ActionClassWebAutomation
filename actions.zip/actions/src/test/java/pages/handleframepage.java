package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.basetest;

public class handleframepage extends basetest {
    WebDriver driver;

    // Constructor
    public handleframepage(WebDriver driver) {
        this.driver = driver;
    }

    // Method to handle frame
    public void handleframe() {
        // Locate the parent frame using XPath from the loc file
        WebElement parentFrame = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("frame1"))));
        
    }
}
