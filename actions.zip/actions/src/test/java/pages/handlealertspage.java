package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import base.basetest;

import java.time.Duration;
import java.util.Set;

public class handlealertspage extends basetest{
    WebDriver driver;
    
    WebElement click_handlealerts;

    public handlealertspage(WebDriver driver) {
        this.driver = driver;
    }
    public void clickonhandlealerts() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("click_handlealerts")))).click();
		try {
	        wait.until(ExpectedConditions.alertIsPresent());
	        Alert alert = driver.switchTo().alert();
	        alert.accept(); // Click the OK button
	        System.out.println("Alert accepted successfully.");
	    } catch (org.openqa.selenium.NoAlertPresentException e) {
	        System.out.println("No alert was present after click_handlealerts.");
	    }
	}
	
}