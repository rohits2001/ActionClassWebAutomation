package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
 
import base.basetest;
 
public class resizewidgetpage  extends basetest {
	WebElement resizewidget;
	WebElement parentframe;

	
	public resizewidgetpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
 
}
	public void navigatetoresizewidget() {
		WebElement parentframe = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("parentframe"))));
		driver.switchTo().frame(parentframe);
		WebElement resizehandle= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("resizewidget"))));
		Actions actions = new Actions(driver);
		actions.dragAndDropBy(resizehandle, 20, 70).perform();
}

 
}