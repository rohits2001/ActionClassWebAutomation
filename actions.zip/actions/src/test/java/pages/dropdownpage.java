package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.*;

import base.basetest;

import java.time.Duration;

public class dropdownpage extends basetest {
   WebElement click_dropdown;
   WebElement click_dropdownoption;


	public dropdownpage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

    // Method to click the dropdown
    public void dropdowntest() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("click_dropdown")))).click();
	}
    
    public void dropdownoptiontest() {
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("click_dropdownoption")))).click();
	}
        }