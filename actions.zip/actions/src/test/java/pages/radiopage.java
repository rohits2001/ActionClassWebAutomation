package pages;

import java.time.Duration;

import org.openqa.selenium.*;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import base.basetest;

public class radiopage extends basetest {
    WebDriver driver;
    
    WebElement click_checkboxradio;
    WebElement frame;
    WebElement click_radio;
    
    public radiopage(WebDriver driver) {
        this.driver = driver;

    }
    
    public void clickoncheckboxradio() {
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath(loc.getProperty("click_checkboxradio")))).click();
	}
    
    public void navigatetoframe() {
	WebElement frame = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("frame"))));
	driver.switchTo().frame(frame);
    }

    public void clickonradio() {
    	wait.until(ExpectedConditions.elementToBeClickable(By.xpath(loc.getProperty("click_radio")))).click();
    }
}
