package pages;
 
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
 
import base.basetest;
 
public class sliderpage extends basetest {
	WebElement slider;
	public void Slider(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
 
}
	public void navigateToSlider() {
		WebElement slider= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("slider"))));
		Actions actions = new Actions(driver);
		actions.dragAndDropBy(slider, 100, 0).perform();
	}
}