package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;

import base.basetest;

import java.time.Duration;

public class mousehovereventpage extends basetest {
    private WebDriver driver;
    private WebDriverWait wait;

    // Locator for the mouse hover element
    private By mousehoverelementlocator;

    public mousehovereventpage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Initialize wait
        this.mousehoverelementlocator = By.xpath(loc.getProperty("click_mousehoverevent")); // Load locator
    }

    // Method to perform mouse hover action
    public void clickOnMouseHoverEvent() {
        // Wait for the element to be visible and locate it
        WebElement mousehoverelement = wait.until(ExpectedConditions.visibilityOfElementLocated(mousehoverelementlocator));
        
        // Perform mouse hover action
        new Actions(driver)
                .moveToElement(mousehoverelement)
                .perform();

        // Optionally, click on the element
        mousehoverelement.click();
    }
}
