package pages;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.*;
import base.basetest;

import java.time.Duration;

public class draganddroppage extends basetest {
    WebDriver driver;
    WebDriverWait wait;
    
    public draganddroppage(WebDriver driver) {
        this.driver = driver;
        // Initialize WebDriverWait
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void draganddrop() {
        // Wait for the 'from' and 'to' elements to be visible
        WebElement from = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("drag"))));
        WebElement to = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(loc.getProperty("drop"))));
        
        // Perform the drag-and-drop action
        Actions actions = new Actions(driver);
        actions.dragAndDrop(from, to).perform();
    }
}
